#!/usr/bin/env python3
"""Editor de Reels (versão para a aba Code do Claude).

Corta silêncios, deixa em 9:16, legenda automática pela fala (Whisper), junta vários
clipes com transições, aplica cor, efeitos visuais, textos animados, música de fundo
da biblioteca NutriAcademy e tratamento de voz, tudo numa única renderização.

Uso:
    python editar.py video.mp4
    python editar.py video.mp4 --clima animada --logo logo.png --zoom-enfase --estilo vivo
    python editar.py parte1.mp4 parte2.mp4 --transicao dissolver
    python editar.py video.mp4 --titulo "3 erros que..." --chamada "Comente EU QUERO" --barra-progresso
    python editar.py --listar-musicas
    python editar.py --listar-efeitos
"""
import argparse
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import efeitos
import fala
import legenda
import musicas
from base import FFMPEG, FONTS_DIR, FPS, HEIGHT, WIDTH, ff_path, is_image, log, media_duration


# ---------------------------------------------------------------- linha do tempo

class Clip:
    def __init__(self, path, index):
        self.path = path
        self.index = index            # posição como entrada do FFmpeg
        self.duration = media_duration(path)
        self.has_audio = "Audio:" in subprocess.run([FFMPEG, "-hide_banner", "-i", str(path)],
                                                     capture_output=True, text=True).stderr
        self.words = []               # palavras no tempo original do clipe
        self.keep = [[0.0, self.duration]]
        self.speeds = []              # (início, fim, fator) no tempo original
        self.pieces = []              # trechos finais: dict(x, y, speed, n0, n1, zoom)
        self.offset = 0.0             # onde o clipe começa no vídeo final

    @property
    def new_duration(self):
        return self.pieces[-1]["n1"] if self.pieces else 0.0

    def build_pieces(self):
        """Trechos mantidos, divididos onde a velocidade muda."""
        out, n = [], 0.0
        for a, b in self.keep:
            cuts = {a, b}
            for sa, sb, _ in self.speeds:
                cuts.update(t for t in (sa, sb) if a < t < b)
            edges = sorted(cuts)
            for x, y in zip(edges, edges[1:]):
                if y - x < 0.04:
                    continue
                mid = (x + y) / 2
                f = next((s for sa, sb, s in self.speeds if sa <= mid < sb), 1.0)
                out.append({"x": x, "y": y, "speed": f, "n0": n, "n1": n + (y - x) / f, "zoom": False})
                n = out[-1]["n1"]
        self.pieces = out

    def to_new(self, t):
        for p in self.pieces:
            if p["x"] <= t < p["y"] + 1e-6:
                return p["n0"] + (t - p["x"]) / p["speed"]
        return None

    def split_for_zoom(self, windows):
        """Divide os trechos nas bordas do zoom (janelas no tempo local do clipe)."""
        out = []
        for p in self.pieces:
            cuts = {p["n0"], p["n1"]}
            for za, zb in windows:
                cuts.update(t for t in (za, zb) if p["n0"] < t < p["n1"])
            edges = sorted(cuts)
            for n0, n1 in zip(edges, edges[1:]):
                if n1 - n0 < 0.04:
                    continue
                mid = (n0 + n1) / 2
                out.append({**p, "x": p["x"] + (n0 - p["n0"]) * p["speed"],
                            "y": p["x"] + (n1 - p["n0"]) * p["speed"], "n0": n0, "n1": n1,
                            "zoom": any(za <= mid < zb for za, zb in windows)})
        self.pieces = out


def parse_speeds(specs, clips):
    """'10-13:0.5' ou '2@10-13:0.5' (clipe 2). Tempo do vídeo original, em segundos."""
    for spec in specs:
        target = clips[0]
        if "@" in spec:
            idx, spec = spec.split("@", 1)
            target = clips[int(idx) - 1]
        rng, factor = spec.rsplit(":", 1)
        a, b = efeitos.parse_range(rng, target.duration)
        f = float(factor)
        if not 0.1 <= f <= 8:
            sys.exit("A velocidade precisa ficar entre 0.1 (bem lenta) e 8 (bem acelerada).")
        target.speeds.append((a, b, f))


def atempo(f):
    """O atempo aceita de 0.5 a 100 por etapa; abaixo de 0.5 encadeia."""
    parts = []
    while f < 0.5:
        parts.append("atempo=0.5")
        f /= 0.5
    parts.append(f"atempo={f:.4f}")
    return ",".join(parts)


# ---------------------------------------------------------------- filtros

class Graph:
    def __init__(self):
        self.lines, self.n = [], 0

    def label(self, prefix="t"):
        self.n += 1
        return f"[{prefix}{self.n}]"

    def add(self, src, chain, out=None):
        out = out or self.label()
        self.lines.append(f"{src}{chain}{out}")
        return out


def frame_chain(g, src, zoom, args):
    """Enquadra em 9:16: corta as laterais (padrão) ou usa fundo desfocado."""
    z = args.zoom if zoom else 1.0
    if args.fundo_desfocado:
        a, b = g.label(), g.label()
        g.lines.append(f"{src}split{a}{b}")
        bg = g.add(a, f"scale={WIDTH}:{HEIGHT}:force_original_aspect_ratio=increase,crop={WIDTH}:{HEIGHT},gblur=sigma=40")
        fg = g.add(b, f"scale={round(WIDTH * z / 2) * 2}:-2")
        return g.add(f"{bg}{fg}", "overlay=(W-w)/2:(H-h)/2,setsar=1")
    w, h = round(WIDTH * z / 2) * 2, round(HEIGHT * z / 2) * 2
    return g.add(src, f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={WIDTH}:{HEIGHT},setsar=1")


def clip_chain(g, clip, args):
    """Corta, ajusta velocidade e enquadra cada trecho do clipe; depois junta."""
    vsrc = f"[{clip.index}:v]"
    if args.estabilizar:
        trf = Path(tempfile.gettempdir()) / f"editor-reels-{clip.index}.trf"
        efeitos.stabilize_detect(clip.path, trf)
        vsrc = g.add(vsrc, efeitos.stabilize_filter(trf))
    srcs = [vsrc] * len(clip.pieces)
    if args.estabilizar and len(clip.pieces) > 1:
        srcs = [g.label() for _ in clip.pieces]
        g.lines.append(f"{vsrc}split={len(srcs)}{''.join(srcs)}")
    vs, as_ = [], []
    for p, src in zip(clip.pieces, srcs):
        v = g.add(src, f"trim=start={p['x']:.3f}:end={p['y']:.3f},setpts=(PTS-STARTPTS)/{p['speed']},fps={FPS}")
        vs.append(frame_chain(g, v, p["zoom"], args))
        dur = p["n1"] - p["n0"]
        if clip.has_audio:
            chain = f"atrim=start={p['x']:.3f}:end={p['y']:.3f},asetpts=PTS-STARTPTS"
            if p["speed"] != 1:
                chain += "," + atempo(p["speed"])
            if p["speed"] > 2:
                chain += ",volume=0"       # time-lapse: fala acelerada fica muda
            as_.append(g.add(f"[{clip.index}:a]", chain + ",aformat=sample_rates=48000:channel_layouts=stereo"))
        else:
            as_.append(g.add("", f"anullsrc=r=48000:cl=stereo,atrim=duration={dur:.3f}"))
    if len(vs) == 1:
        v, a = vs[0], as_[0]
    else:
        v, a = g.label(), g.label()
        g.lines.append("".join(x + y for x, y in zip(vs, as_)) + f"concat=n={len(vs)}:v=1:a=1{v}{a}")
    return g.add(v, "settb=AVTB,format=yuv420p"), a


def join_clips(g, clips, streams, args):
    """Une os clipes com a transição escolhida."""
    name = efeitos.TRANSICOES[args.transicao]
    if len(clips) == 1:
        return streams[0]
    if name is None:   # corte seco ou glitch
        v, a = g.label(), g.label()
        g.lines.append("".join(x + y for x, y in streams) + f"concat=n={len(streams)}:v=1:a=1{v}{a}")
        return v, a
    v, a = streams[0]
    d = args.duracao_transicao
    for clip, (cv, ca) in zip(clips[1:], streams[1:]):
        v = g.add(f"{v}{cv}", f"xfade=transition={name}:duration={d}:offset={clip.offset:.3f}")
        a = g.add(f"{a}{ca}", f"acrossfade=d={d}")
    return v, a


def finishing(g, v, a, clips, ass_path, total, args, inputs):
    """Fundo (chroma key), cor, textura, glitch, desfoque, logo, barra, textos e fades."""
    if args.fundo:
        idx = sum(1 for x in inputs if x == "-i")
        loop = ["-loop", "1", "-framerate", str(FPS)] if is_image(args.fundo) else ["-stream_loop", "-1"]
        inputs += [*loop, "-t", f"{total:.3f}", "-i", str(args.fundo)]
        bg = g.add(f"[{idx}:v]", f"scale={WIDTH}:{HEIGHT}:force_original_aspect_ratio=increase,"
                                 f"crop={WIDTH}:{HEIGHT},fps={FPS},format=yuv420p,setpts=PTS-STARTPTS")
        fg = g.add(v, f"chromakey=0x{args.chroma_cor.lstrip('#')}:{args.chroma_tolerancia}:0.08")
        v = g.add(f"{bg}{fg}", "overlay=shortest=1:format=auto")

    chain = efeitos.color_chain(args, [c.path for c in clips]) + efeitos.texture_chain(args)
    if args.transicao == "glitch" and len(clips) > 1:
        win = "+".join(f"between(t,{c.offset - 0.12:.3f},{c.offset + 0.15:.3f})" for c in clips[1:])
        chain += [f"rgbashift=rh=-24:bh=24:gv=8:enable='{win}'", f"noise=alls=45:allf=t:enable='{win}'"]
    if chain:
        v = g.add(v, ",".join(chain))

    for spec in args.desfocar:
        area, _, rng = spec.partition("@")
        x, y, w, h = [int(float(n)) for n in area.split(",")]
        t0, t1 = efeitos.parse_range(rng or "tudo", total)
        m, c = g.label(), g.label()
        g.lines.append(f"{v}split{m}{c}")
        blur = g.add(c, f"crop={w}:{h}:{x}:{y},boxblur=28:6")
        v = g.add(f"{m}{blur}", f"overlay={x}:{y}:enable='between(t,{t0:.2f},{t1:.2f})'")

    if args.logo:
        idx = sum(1 for x in inputs if x == "-i")
        inputs += ["-i", str(args.logo)]
        lg = g.add(f"[{idx}:v]", f"scale={args.logo_largura}:-1,format=rgba,colorchannelmixer=aa=0.9")
        v = g.add(f"{v}{lg}", "overlay=W-w-50:90")

    if args.barra_progresso:
        color = args.cor.lstrip("#")
        bar = g.add("", f"color=c=0x{color}:s={WIDTH}x14:r={FPS}:d={total:.3f}")
        y = "0" if args.barra_progresso == "cima" else "H-h-250"
        v = g.add(f"{v}{bar}", f"overlay=x='-w+w*t/{total:.3f}':y={y}:shortest=1")

    tail = []
    if ass_path:
        tail.append(f"ass='{ff_path(ass_path)}':fontsdir='{ff_path(FONTS_DIR)}'")
    if args.fade_entrada:
        tail.append(f"fade=t=in:st=0:d=0.6:color={args.fade_entrada}")
    if args.fade_saida:
        tail.append(f"fade=t=out:st={max(0.0, total - 0.8):.3f}:d=0.8:color={args.fade_saida}")
    tail.append("format=yuv420p")
    g.add(v, ",".join(tail), "[vout]")

    # Áudio
    chain = efeitos.voice_chain(args)
    if chain:
        a = g.add(a, ",".join(chain))
    if args.eco:
        echo = "aecho=0.8:0.6:60|120:0.35|0.2"
        if args.eco == "tudo":
            a = g.add(a, echo)
        else:
            t0, t1 = efeitos.parse_range(args.eco, total)
            dry, wet = g.label(), g.label()
            g.lines.append(f"{a}asplit{dry}{wet}")
            we = g.add(wet, f"{echo},volume=0:enable='not(between(t,{t0},{t1}))'")
            dr = g.add(dry, f"volume=0:enable='between(t,{t0},{t1})'")
            a = g.add(f"{dr}{we}", "amix=inputs=2:normalize=0")
    if args.musica:
        idx = sum(1 for x in inputs if x == "-i")
        inputs += ["-stream_loop", "-1", "-i", str(args.musica)]
        vm, vk = g.label(), g.label()
        g.lines.append(f"{a}asplit{vm}{vk}")
        mus = g.add(f"[{idx}:a]", f"aformat=sample_rates=48000:channel_layouts=stereo,volume={args.volume_musica},"
                                  f"atrim=0:{total:.3f},afade=t=in:d=1,afade=t=out:st={max(0.0, total - 2):.3f}:d=2")
        # A música abaixa sozinha enquanto há voz e volta nas pausas.
        duck = g.add(f"{mus}{vk}", "sidechaincompress=threshold=0.02:ratio=10:attack=15:release=500")
        a = g.add(f"{vm}{duck}", "amix=inputs=2:duration=first:normalize=0")
    fades = []
    if args.fade_entrada:
        fades.append("afade=t=in:d=0.6")
    if args.fade_saida:
        fades.append(f"afade=t=out:st={max(0.0, total - 0.8):.3f}:d=0.8")
    g.add(a, ",".join(fades) if fades else "anull", "[aout]")


def render(clips, dst, ass_path, total, args):
    g = Graph()
    inputs = []
    for c in clips:
        inputs += ["-i", str(c.path)]
    streams = [clip_chain(g, c, args) for c in clips]
    v, a = join_clips(g, clips, streams, args)
    finishing(g, v, a, clips, ass_path, total, args, inputs)

    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as fh:
        fh.write(";\n".join(g.lines))
        script = fh.name
    log("Renderizando o vídeo final…")
    t0 = time.time()
    cmd = [FFMPEG, "-y", "-hide_banner", "-loglevel", "error", *inputs,
           "-filter_complex_script", script, "-map", "[vout]", "-map", "[aout]",
           "-c:v", "libx264", "-preset", args.preset, "-crf", "21", "-r", str(FPS),
           "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-t", f"{total:.3f}", str(dst)]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        sys.exit(f"Erro no FFmpeg:\n{p.stderr[-2500:]}\n(filtros em {script})")
    log(f"Renderizado em {time.time() - t0:.0f}s")


def preview(dst, out_png, duration, times=None):
    """Uma imagem com 3 quadros do vídeo final, para conferir legenda, textos e efeitos."""
    times = times or [duration * x for x in (0.08, 0.5, 0.92)]
    inputs, maps = [], []
    for i, t in enumerate(times):
        inputs += ["-ss", f"{min(t, duration - 0.1):.2f}", "-i", str(dst)]
        maps.append(f"[{i}:v]scale=360:-1[p{i}]")
    graph = ";".join(maps) + ";" + "".join(f"[p{i}]" for i in range(len(times))) + f"hstack={len(times)}"
    subprocess.run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", *inputs,
                    "-filter_complex", graph, "-frames:v", "1", str(out_png)], check=False)


# ---------------------------------------------------------------- main

EFEITOS_AJUDA = """EFEITOS DISPONÍVEIS

Transições (entre vários clipes):  --transicao <nome>  [--duracao-transicao 0.5]
  {transicoes}
Fade no começo/fim:                --fade-entrada preto|branco   --fade-saida preto|branco

Cor:
  --corrigir-cor                   balanço de branco e exposição automáticos
  --estilo <nome>                  {estilos}
  --lut arquivo.cube               filtro de cor pronto (LUT)
  --brilho -0.1..0.1  --contraste 0.8..1.4  --saturacao 0..2

Efeitos visuais:
  --fundo imagem_ou_video          troca o fundo verde (chroma key)  [--chroma-cor 00FF00 --chroma-tolerancia 0.15]
  --fundo-desfocado                vídeo horizontal inteiro, com fundo desfocado
  --desfocar x,y,l,a[@ini-fim]     borra uma área (ex.: rosto, documento, placa); pode repetir
  --velocidade ini-fim:fator       0.5 = câmera lenta, 3 = time-lapse (fica sem som); pode repetir
  --estabilizar                    reduz o tremor do celular
  --granulado 10                   textura de filme (5 a 25)
  --vinheta                        bordas escurecidas
  --zoom-enfase [--zoom 1.15]      zoom alternado a cada frase

Textos e gráficos:
  --titulo "texto" [--titulo-duracao 3]               título animado de abertura
  --nome "Dra. Ana" [--subtitulo "Nutricionista"]     apresentação (lower third)  [--nome-inicio 1 --nome-duracao 4]
  --chamada "Comente EU QUERO" [--chamada-duracao 3]  chamada final pulsando
  --destaque "proteína,grátis"                        palavras maiores na legenda
  --barra-progresso [cima|baixo]                      barra que enche ao longo do vídeo
  --logo logo.png

Áudio:
  --reduzir-ruido                  limpa chiado, ar-condicionado, vento leve
  --voz clara|encorpada            equalização da voz
  --eco [ini-fim]                  eco/reverb no vídeo todo ou num trecho
  --normalizar                     volume da voz padronizado
  --clima calma|animada|inspiradora|corporativa   música da biblioteca
"""


def build_parser():
    p = argparse.ArgumentParser(description="Editor de Reels")
    p.add_argument("videos", type=Path, nargs="*")
    p.add_argument("--listar-musicas", action="store_true")
    p.add_argument("--listar-efeitos", action="store_true")
    p.add_argument("-o", "--saida", type=Path)
    # fala e legenda
    p.add_argument("--roteiro", type=Path)
    p.add_argument("--modelo", default="small")
    p.add_argument("--idioma", default="pt")
    p.add_argument("--retranscrever", action="store_true")
    p.add_argument("--trocar", action="append", default=[], metavar="ERRADO=CERTO")
    p.add_argument("--pausa", type=float, default=0.45)
    p.add_argument("--margem", type=float, default=0.15)
    p.add_argument("--ruido", type=float)
    p.add_argument("--sem-cortes", action="store_true")
    p.add_argument("--sem-legenda", action="store_true")
    p.add_argument("--palavras", type=int, default=3)
    p.add_argument("--cor", default="#FFD400")
    p.add_argument("--fonte", default="Anton")
    p.add_argument("--tamanho", type=int, default=104)
    p.add_argument("--altura", type=int, default=560)
    p.add_argument("--minusculas", dest="maiusculas", action="store_false")
    p.add_argument("--destaque")
    # textos
    p.add_argument("--titulo")
    p.add_argument("--titulo-duracao", type=float, default=3.0)
    p.add_argument("--nome")
    p.add_argument("--subtitulo")
    p.add_argument("--nome-inicio", type=float, default=1.0)
    p.add_argument("--nome-duracao", type=float, default=4.0)
    p.add_argument("--chamada")
    p.add_argument("--chamada-duracao", type=float, default=3.0)
    p.add_argument("--barra-progresso", nargs="?", const="cima", choices=["cima", "baixo"])
    p.add_argument("--logo", type=Path)
    p.add_argument("--logo-largura", type=int, default=200)
    # transições
    p.add_argument("--transicao", default="corte", choices=list(efeitos.TRANSICOES))
    p.add_argument("--duracao-transicao", type=float, default=0.5)
    p.add_argument("--fade-entrada", nargs="?", const="black", choices=["black", "white", "preto", "branco"])
    p.add_argument("--fade-saida", nargs="?", const="black", choices=["black", "white", "preto", "branco"])
    # cor e efeitos
    p.add_argument("--corrigir-cor", action="store_true")
    p.add_argument("--estilo", choices=list(efeitos.ESTILOS))
    p.add_argument("--lut", type=Path)
    p.add_argument("--brilho", type=float)
    p.add_argument("--contraste", type=float)
    p.add_argument("--saturacao", type=float)
    p.add_argument("--fundo", type=Path)
    p.add_argument("--chroma-cor", default="00FF00")
    p.add_argument("--chroma-tolerancia", type=float, default=0.15)
    p.add_argument("--fundo-desfocado", action="store_true")
    p.add_argument("--desfocar", action="append", default=[])
    p.add_argument("--velocidade", action="append", default=[])
    p.add_argument("--estabilizar", action="store_true")
    p.add_argument("--granulado", type=float)
    p.add_argument("--vinheta", action="store_true")
    p.add_argument("--zoom-enfase", action="store_true")
    p.add_argument("--zoom", type=float, default=1.15)
    # áudio
    p.add_argument("--reduzir-ruido", action="store_true")
    p.add_argument("--voz", choices=["clara", "encorpada"])
    p.add_argument("--eco", nargs="?", const="tudo")
    p.add_argument("--normalizar", action="store_true")
    p.add_argument("--clima")
    p.add_argument("--musica-id")
    p.add_argument("--musica", type=Path)
    p.add_argument("--volume-musica", type=float, default=0.25)
    p.add_argument("--preset", default="veryfast")
    return p


def main():
    p = build_parser()
    args = p.parse_args()
    if args.listar_musicas:
        musicas.list_music()
        return
    if args.listar_efeitos:
        print(EFEITOS_AJUDA.format(transicoes=", ".join(efeitos.TRANSICOES), estilos=", ".join(efeitos.ESTILOS)))
        return
    if not args.videos:
        p.error("informe pelo menos um vídeo")
    for side in ("fade_entrada", "fade_saida"):
        val = getattr(args, side)
        if val in ("preto", "branco"):
            setattr(args, side, {"preto": "black", "branco": "white"}[val])

    paths = [v.expanduser().resolve() for v in args.videos]
    for f in [*paths, args.roteiro, args.musica, args.logo, args.fundo, args.lut]:
        if f and not Path(f).expanduser().exists():
            sys.exit(f"Arquivo não encontrado: {f}")
    if args.roteiro and len(paths) > 1:
        sys.exit("O roteiro só funciona com um vídeo por vez.")
    dst = (args.saida or paths[0].with_name(f"{paths[0].stem}_reel.mp4")).expanduser().resolve()
    if args.clima or args.musica_id:
        args.musica, _ = musicas.pick_music(args.clima, args.musica_id)

    clips = [Clip(path, i) for i, path in enumerate(paths)]
    for c in clips:
        log(f"Vídeo {c.index + 1}: {c.path.name} ({c.duration:.1f}s)")
    parse_speeds(args.velocidade, clips)

    # 1. Fala de cada clipe (Whisper) e cortes.
    for c in clips:
        if args.roteiro or not c.has_audio:
            words = []
        else:
            cache = c.path.with_name(f"{c.path.stem}.palavras.json")
            if cache.exists() and not args.retranscrever:
                log(f"Usando a transcrição já feita de {c.path.name}")
                words = json.loads(cache.read_text(encoding="utf-8"))
            else:
                words = fala.transcribe(c.path, args.modelo, args.idioma)
                if words is None:
                    log("Whisper não instalado: rode instalar.py. Seguindo sem legenda automática.")
                    words = []
                else:
                    cache.write_text(json.dumps(words, ensure_ascii=False), encoding="utf-8")
        c.words = fala.apply_corrections(words, args.trocar)
        if not args.sem_cortes and c.has_audio:
            if c.words:
                c.keep = fala.keep_from_words(c.words, args.pausa, args.margem, c.duration)
            else:
                speech = fala.speech_segments(c.path, c.duration, args.pausa, args.ruido)
                c.keep = fala.pad_and_merge(speech, args.margem, c.duration)
        if args.roteiro:
            log("Encaixando o roteiro na fala…")
            script_words = fala.read_script(args.roteiro.read_text(encoding="utf-8"))
            c.words = fala.apply_corrections(fala.align(script_words, c.path), args.trocar)
        c.build_pieces()

    # 2. Posição de cada clipe no vídeo final (transições sobrepõem os clipes).
    d = args.duracao_transicao if efeitos.TRANSICOES[args.transicao] else 0.0
    offset = 0.0
    for c in clips:
        if d and c.new_duration <= d + 0.1:
            sys.exit(f"O clipe {c.path.name} é curto demais para a transição de {d}s.")
        c.offset = offset
        offset += c.new_duration - d
    total = offset + d

    # 3. Palavras no tempo do vídeo final.
    words = []
    for c in clips:
        for w in c.words:
            s, e = c.to_new(w["start"]), c.to_new(min(w["end"], w["start"] + 1.5))
            if s is not None:
                words.append({**w, "start": c.offset + s, "end": c.offset + (e if e is not None else s + 0.3)})
    words.sort(key=lambda w: w["start"])
    speech = [[w["start"], w["end"]] for w in words] or [[c.offset, c.offset + c.new_duration] for c in clips]

    # 4. Zoom de ênfase.
    if args.zoom_enfase:
        windows = legenda.zoom_windows(words, speech, total)
        for c in clips:
            local = [(max(0.0, a - c.offset), min(c.new_duration, b - c.offset)) for a, b in windows
                     if b > c.offset and a < c.offset + c.new_duration]
            c.split_for_zoom(local)

    # 5. Legenda e textos.
    ass_path = None
    chunks = legenda.chunk_words(words, args.palavras) if words and not args.sem_legenda else []
    if chunks:
        legenda.write_srt(chunks, dst.with_suffix(".srt"))
        dst.with_suffix(".txt").write_text(" ".join(w["text"] for w in words), encoding="utf-8")
        log(f"Legenda: {len(words)} palavras em {len(chunks)} blocos")
    if chunks or args.titulo or args.nome or args.chamada:
        ass_path = Path(tempfile.mkdtemp()) / "textos.ass"
        legenda.write_ass(ass_path, chunks, args, total)

    log(f"Duração final: {total:.1f}s")
    render(clips, dst, ass_path, total, args)
    prev = dst.with_name(dst.stem + "_previa.png")
    preview(dst, prev, total)
    log(f"Pronto: {dst}")
    if prev.exists():
        log(f"Prévia: {prev}")


if __name__ == "__main__":
    main()
