"""Legenda animada e textos na tela (título, nome, chamada) em formato ASS."""
import re

from base import HEIGHT, SENTENCE_END, WIDTH, norm


def chunk_words(words, max_words, max_chars=22):
    chunks, cur = [], []
    for w in words:
        if cur and (len(cur) >= max_words or len(" ".join(x["text"] for x in cur + [w])) > max_chars):
            chunks.append(cur)
            cur = []
        cur.append(w)
        if re.search(r"[.!?…,;:]$", w["text"]):
            chunks.append(cur)
            cur = []
    if cur:
        chunks.append(cur)
    return chunks


def ass_time(t):
    cs = int(round(max(0.0, t) * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def srt_time(t):
    ms = int(round(max(0.0, t) * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def hex_to_ass(color):
    c = color.lstrip("#")
    return f"&H00{c[4:6]}{c[2:4]}{c[0:2]}".upper()


def write_srt(chunks, path):
    out = []
    for i, c in enumerate(chunks, 1):
        out.append(f"{i}\n{srt_time(c[0]['start'])} --> {srt_time(c[-1]['end'])}\n{' '.join(w['text'] for w in c)}\n")
    path.write_text("\n".join(out), encoding="utf-8")


def zoom_windows(words, speech, total):
    """Uma frase normal, a seguinte com zoom. Sem roteiro, alterna a cada trecho de fala."""
    if words:
        starts, new = [], True
        for w in words:
            if new:
                starts.append(w["start"])
            new = bool(SENTENCE_END.search(w["text"]))
    else:
        starts = [a for a, _ in speech]
    bounds = starts[1:] + [total]
    return [(a, b) for k, (a, b) in enumerate(zip(starts, bounds)) if k % 2 == 1]


def ass_text(text):
    return text.replace("{", "").replace("}", "").replace("\n", "\\N")


def write_ass(path, chunks, args, duration):
    """Gera o arquivo ASS com a legenda animada e os textos na tela."""
    hi = hex_to_ass(args.cor)
    highlights = {norm(w) for w in (args.destaque or "").split(",") if norm(w)}
    font = args.fonte
    lines = [f"""[Script Info]
ScriptType: v4.00+
PlayResX: {WIDTH}
PlayResY: {HEIGHT}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Reel,{font},{args.tamanho},&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,0,0,0,0,100,100,1,0,1,7,3,2,80,80,{args.altura},1
Style: Titulo,{font},122,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,1,0,1,9,4,8,70,70,300,1
Style: Nome,{font},88,&H00000000,&H00000000,{hi},{hi},0,0,0,0,100,100,1,0,3,14,0,1,70,70,0,1
Style: Sub,{font},58,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,1,0,3,12,0,1,70,70,0,1
Style: Chamada,{font},118,&H00000000,&H00000000,{hi},{hi},0,0,0,0,100,100,1,0,3,22,0,5,90,90,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""]

    def event(start, end, style, text, layer=0):
        lines.append(f"Dialogue: {layer},{ass_time(start)},{ass_time(end)},{style},,0,0,0,,{text}\n")

    # Legenda: a palavra falada fica colorida; palavras-chave ficam maiores.
    for n, chunk in enumerate(chunks):
        nxt = chunks[n + 1][0]["start"] if n + 1 < len(chunks) else chunk[-1]["end"] + 0.3
        for j, w in enumerate(chunk):
            end = chunk[j + 1]["start"] if j + 1 < len(chunk) else min(nxt, chunk[-1]["end"] + 0.3)
            parts = []
            for k, x in enumerate(chunk):
                t = ass_text(x["text"].upper() if args.maiusculas else x["text"])
                big = norm(x["text"]) in highlights
                if k == j or big:
                    size = f"\\fscx125\\fscy125" if big else ""
                    parts.append(f"{{\\c{hi}{size}}}{t}{{\\c&H00FFFFFF&\\fscx100\\fscy100}}")
                else:
                    parts.append(t)
            event(w["start"], end, "Reel", " ".join(parts))

    # Título de abertura: entra "pulando" e some suavemente.
    if args.titulo:
        t = ass_text(args.titulo.upper())
        event(0.0, args.titulo_duracao, "Titulo",
              f"{{\\fad(120,300)\\fscx40\\fscy40\\t(0,180,\\fscx112\\fscy112)\\t(180,300,\\fscx100\\fscy100)}}{t}", 2)

    # Lower third (nome + subtítulo): desliza da esquerda.
    if args.nome:
        a, b = args.nome_inicio, args.nome_inicio + args.nome_duracao
        y = HEIGHT - args.altura - 380
        event(a, b, "Nome", f"{{\\fad(0,300)\\move(-700,{y},70,{y},0,350)}}{ass_text(args.nome)}", 3)
        if args.subtitulo:
            event(a + 0.15, b, "Sub",
                  f"{{\\fad(0,300)\\move(-700,{y + 118},70,{y + 118},0,350)}}{ass_text(args.subtitulo)}", 3)

    # Chamada final: aparece nos últimos segundos e pulsa.
    if args.chamada:
        a = max(0.0, duration - args.chamada_duracao)
        pulse = "".join(f"\\t({ms},{ms + 300},\\fscx106\\fscy106)\\t({ms + 300},{ms + 600},\\fscx100\\fscy100)"
                        for ms in range(400, int(args.chamada_duracao * 1000) - 300, 600))
        event(a, duration, "Chamada",
              f"{{\\pos({WIDTH // 2},430)\\fad(150,0)\\fscx50\\fscy50\\t(0,200,\\fscx100\\fscy100){pulse}}}"
              f"{ass_text(args.chamada.upper())}", 4)

    path.write_text("".join(lines), encoding="utf-8")
