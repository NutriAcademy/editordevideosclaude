"""Biblioteca de músicas NutriAcademy (CC0), baixada sob demanda."""
import json
import os
import random
import re
import sys
import urllib.request
from pathlib import Path

from base import CONFIG, HOME, log, norm


def library_dir():
    d = HOME / "musicas"
    d.mkdir(parents=True, exist_ok=True)
    return d


def library_url():
    if os.environ.get("EDITOR_REELS_MUSICAS"):
        return os.environ["EDITOR_REELS_MUSICAS"]
    if CONFIG.exists():
        return json.loads(CONFIG.read_text(encoding="utf-8")).get("biblioteca_url", "")
    return ""


def fetch(url, dst):
    if re.match(r"^https?://|^file://", url):
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "editor-reels"}), timeout=60) as r:
            data = r.read()
    else:
        data = Path(url).expanduser().read_bytes()
    tmp = dst.with_suffix(dst.suffix + ".part")
    tmp.write_bytes(data)
    tmp.replace(dst)


def load_catalog(update=False):
    """Catálogo da biblioteca NutriAcademy, baixado e guardado no computador."""
    d = library_dir()
    local = d / "catalogo.json"
    base = library_url().rstrip("/")
    if base and (update or not local.exists()):
        try:
            fetch(f"{base}/catalogo.json", local)
        except Exception as e:  # noqa: BLE001
            if not local.exists():
                sys.exit(f"Não consegui baixar a biblioteca de músicas ({e}).")
            log("Sem conexão com a biblioteca; usando a versão já baixada.")
    if not local.exists():
        sys.exit("Biblioteca de músicas não configurada (config.json → biblioteca_url).")
    return json.loads(local.read_text(encoding="utf-8"))


def pick_music(clima, music_id=None):
    catalog = load_catalog()
    tracks = catalog["musicas"]
    if music_id:
        track = next((t for t in tracks if t["id"] == music_id or norm(t["titulo"]) == norm(music_id)), None)
        if not track:
            sys.exit(f"Música não encontrada na biblioteca: {music_id}")
    else:
        options = [t for t in tracks if t["clima"] == clima]
        if not options:
            climas = sorted({t["clima"] for t in tracks})
            sys.exit(f"Clima '{clima}' não existe. Opções: {', '.join(climas)}")
        track = random.choice(options)
    path = library_dir() / track["arquivo"]
    if not path.exists():
        log(f"Baixando a música \"{track['titulo']}\"…")
        fetch(f"{library_url().rstrip('/')}/{track['arquivo']}", path)
    log(f"Música: {track['titulo']} — {track['autor']} ({track['clima']}, licença CC0)")
    return path, track


def list_music():
    catalog = load_catalog(update=True)
    for clima in ("calma", "animada", "inspiradora", "corporativa"):
        print(f"\n{clima.upper()}")
        for t in catalog["musicas"]:
            if t["clima"] == clima:
                print(f"  {t['id']:40s} {t['titulo']} — {t['descricao']}")
    print(f"\nLicença: {catalog.get('licenca', '')}")
