"""Utilidades comuns do Editor de Reels: FFmpeg, caminhos e mensagens."""
import re
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
FONTS_DIR = HERE.parent / "fonts"
HOME = Path.home() / ".editor-reels"
CONFIG = HERE / "config.json"
WIDTH, HEIGHT, FPS = 1080, 1920, 30
SENTENCE_END = re.compile(r"[.!?…]$")


def log(msg):
    print(f"▸ {msg}", flush=True)


def find_ffmpeg():
    # O FFmpeg instalado pelo instalar.py tem suporte a legenda garantido; o do sistema é o reserva.
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:  # noqa: BLE001
        path = shutil.which("ffmpeg")
        if path:
            return path
        sys.exit("FFmpeg não encontrado: rode instalar.py primeiro.")


FFMPEG = find_ffmpeg()


def ffmpeg_stderr(args):
    return subprocess.run([FFMPEG, "-hide_banner", *args], capture_output=True, text=True).stderr


def media_duration(path):
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", ffmpeg_stderr(["-i", str(path)]))
    return int(m[1]) * 3600 + int(m[2]) * 60 + float(m[3]) if m else 0.0


def ff_path(p):
    """Caminho seguro para usar dentro de um filtro do FFmpeg (inclusive no Windows)."""
    return str(p).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")


def norm(text):
    return re.sub(r"[^\wáéíóúàãõâêôç]", "", text.lower())


def is_image(path):
    return Path(path).suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
