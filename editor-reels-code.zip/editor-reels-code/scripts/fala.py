"""Fala: transcrição (Whisper), silêncios, roteiro e correções de legenda."""
import array
import json
import math
import os
import re
import subprocess

from base import FFMPEG, HOME, SENTENCE_END, ffmpeg_stderr, log, norm

CORRECOES = HOME / "correcoes.txt"


def speech_segments(path, duration, min_silence, noise_db):
    """Trechos com fala, a partir do silencedetect do FFmpeg."""
    if noise_db is None:
        m = re.search(r"mean_volume: (-?[\d.]+) dB",
                      ffmpeg_stderr(["-i", str(path), "-vn", "-af", "volumedetect", "-f", "null", "-"]))
        mean = float(m[1]) if m else -25.0
        noise_db = min(-25.0, max(-55.0, mean - 12))
    log(f"Detectando silêncios (limite {noise_db:.0f} dB)…")
    err = ffmpeg_stderr(["-i", str(path), "-vn", "-af",
                         f"silencedetect=noise={noise_db}dB:d={min_silence}", "-f", "null", "-"])
    starts = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", err)]
    ends = [float(x) for x in re.findall(r"silence_end: (-?[\d.]+)", err)]
    silences = list(zip(starts, ends + [duration] * (len(starts) - len(ends))))
    speech, cursor = [], 0.0
    for s, e in silences:
        if s - cursor > 0.15:
            speech.append([cursor, s])
        cursor = max(cursor, e)
    if duration - cursor > 0.15:
        speech.append([cursor, duration])
    return speech or [[0.0, duration]]


def pad_and_merge(speech, pad, duration):
    out = []
    for a, b in speech:
        a, b = max(0.0, a - pad), min(duration, b + pad)
        if out and a <= out[-1][1]:
            out[-1][1] = b
        else:
            out.append([a, b])
    return out


def remap_speech(speech, keep):
    """Converte os trechos de fala para a linha do tempo já cortada."""
    out, offset = [], 0.0
    for k_start, k_end in keep:
        for s, e in speech:
            a, b = max(s, k_start), min(e, k_end)
            if b > a:
                out.append([offset + a - k_start, offset + b - k_start])
        offset += k_end - k_start
    return out


# ---------------------------------------------------------------- roteiro → tempo

VOWELS = re.compile(r"[aeiouáéíóúâêôãõàyü]+", re.I)


def weight(word):
    """Peso falado aproximado de uma palavra: número de sílabas (grupos de vogais)."""
    digits = len(re.findall(r"\d", word))
    return max(1, len(VOWELS.findall(word)) + 2 * digits)


def read_script(text):
    text = re.sub(r"\[[^\]]*\]|\([^)]*\)", " ", text)          # remove [pausa], (rindo)…
    text = re.sub(r"(?m)^\s*(gancho|hook|cta|corpo|cena|take)\s*\d*\s*[:\-–]\s*", "", text, flags=re.I)
    words = []
    for line in text.splitlines():
        tokens = line.split()
        for i, t in enumerate(tokens):
            if re.search(r"\w", t):
                # fim de linha também conta como fim de frase
                if i == len(tokens) - 1 and not re.search(r"[.!?…,;:]$", t):
                    t += "."
                words.append(t)
    return words


def energy_envelope(path):
    """Energia do áudio em dB a cada 10 ms (suavizada)."""
    raw = subprocess.run([FFMPEG, "-v", "error", "-i", str(path), "-vn", "-ac", "1", "-ar", "16000",
                          "-f", "s16le", "-"], capture_output=True).stdout
    try:
        import numpy as np
        x = np.frombuffer(raw, dtype=np.int16).astype(np.float64)
        n = len(x) // 160
        env = 10 * np.log10((x[:n * 160].reshape(n, 160) ** 2).mean(axis=1) + 1e-9)
        env = np.convolve(env, np.ones(5) / 5, mode="same").tolist()
    except ImportError:
        pcm = array.array("h")
        pcm.frombytes(raw)
        env = [10 * math.log10(sum(v * v for v in pcm[i:i + 160]) / 160 + 1e-9)
               for i in range(0, len(pcm) - 160, 160)]
        env = [sum(env[max(0, i - 2):i + 3]) / len(env[max(0, i - 2):i + 3]) for i in range(len(env))]
    return env


def syllable_peaks(env, frac=0.45, min_dist=8, dip=1.5):
    """Picos de energia: cada um costuma ser o núcleo de uma sílaba falada."""
    ordered = sorted(env)
    floor, top = ordered[len(ordered) // 10], ordered[int(len(ordered) * 0.95)]
    thr = floor + frac * (top - floor)
    peaks, last, low = [], -999, 1e9
    for i in range(1, len(env) - 1):
        low = min(low, env[i])
        if env[i] >= env[i - 1] and env[i] > env[i + 1] and env[i] > thr:
            if i - last >= min_dist and (not peaks or max(env[peaks[-1]], env[i]) - low >= dip):
                peaks.append(i)
                last, low = i, 1e9
            elif peaks and env[i] > env[peaks[-1]] and i - last < min_dist:
                peaks[-1] = i
                last = i
    return [i * 0.01 for i in peaks]


def align(words, path):
    """Encaixa as sílabas do roteiro nos picos de energia da fala (alinhamento por DTW).

    Pausas longas entre picos atraem fins de frase/vírgula do roteiro. Retorna o
    tempo de cada palavra na linha do tempo do vídeo original.
    """
    peaks = syllable_peaks(energy_envelope(path))
    if len(peaks) < 2:
        return []
    syl = []  # (palavra, depois de pontuação, depois de fim de frase)
    for k, w in enumerate(words):
        prev = words[k - 1] if k else "."
        after, strong = bool(re.search(r"[.!?…,;:]$", prev)), bool(SENTENCE_END.search(prev))
        for j in range(weight(w)):
            syl.append((k, j == 0 and after, j == 0 and strong))

    S, P = len(syl), len(peaks)
    gap = [99.0] + [peaks[i] - peaks[i - 1] for i in range(1, P)]
    skip_s, skip_p, bonus, gap_pen, gap_t = 0.6, 0.6, 1.0, 0.5, 0.3
    INF = float("inf")
    D = [[INF] * (P + 1) for _ in range(S + 1)]
    B = [[0] * (P + 1) for _ in range(S + 1)]
    D[0][0] = 0.0
    for s in range(S + 1):
        Ds, Bs = D[s], B[s]
        Dp = D[s - 1] if s else None
        if s:
            _, after, strong = syl[s - 1]
        for p in range(P + 1):
            if s == 0 and p == 0:
                continue
            best, arg = INF, 0
            if s and p:
                long_gap = gap[p - 1] > gap_t
                if long_gap and after:
                    c = -bonus * (2 if strong else 1)
                elif long_gap:
                    c = gap_pen
                elif strong:
                    c = gap_pen * 0.5
                else:
                    c = 0.0
                best, arg = Dp[p - 1] + c, 1
            if s and Dp[p] + skip_s < best:
                best, arg = Dp[p] + skip_s, 2
            if p and Ds[p - 1] + skip_p < best:
                best, arg = Ds[p - 1] + skip_p, 3
            Ds[p], Bs[p] = best, arg

    t_syl = [None] * S
    s, p = S, P
    while s or p:
        a = B[s][p]
        if a == 1:
            t_syl[s - 1] = peaks[p - 1]
            s, p = s - 1, p - 1
        elif a == 2:
            s -= 1
        else:
            p -= 1
    known = [i for i, t in enumerate(t_syl) if t is not None]
    for i in range(S):  # sílabas sem pico: interpola entre as vizinhas
        if t_syl[i] is None:
            prev = max((k for k in known if k < i), default=None)
            nxt = min((k for k in known if k > i), default=None)
            if prev is not None and nxt is not None:
                t_syl[i] = t_syl[prev] + (t_syl[nxt] - t_syl[prev]) * (i - prev) / (nxt - prev)
            else:
                t_syl[i] = t_syl[prev if prev is not None else nxt]

    starts = {}
    for i, (k, _, _) in enumerate(syl):
        starts.setdefault(k, max(0.0, t_syl[i] - 0.07))
    out = []
    for k, w in enumerate(words):
        start = starts[k]
        end = starts[k + 1] if k + 1 < len(words) else t_syl[-1] + 0.3
        out.append({"text": w, "start": start, "end": max(start + 0.05, min(end, start + 1.5))})
    return out


def remap_words(words, keep):
    """Leva o tempo das palavras para a linha do tempo já cortada."""
    out, offset = [], 0.0
    for a, b in keep:
        for w in words:
            if a <= w["start"] < b:
                out.append({**w, "start": offset + w["start"] - a, "end": offset + min(w["end"], b) - a})
        offset += b - a
    return out


def apply_corrections(words, extra):
    """Regras 'errado=certo' do arquivo correcoes.txt mais as passadas com --trocar."""
    lines = CORRECOES.read_text(encoding="utf-8").splitlines() if CORRECOES.exists() else []
    for line in lines + list(extra):
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        old, new = line.split("=", 1)
        old_t, new_t = [norm(t) for t in old.split() if norm(t)], new.split()
        if not old_t or not new_t:
            continue
        out, i, n = [], 0, len(old_t)
        while i < len(words):
            span = words[i:i + n]
            if len(span) == n and [norm(w["text"]) for w in span] == old_t:
                t0, t1 = span[0]["start"], span[-1]["end"]
                tail = re.search(r"[.,!?…:;]+$", span[-1]["text"])
                step = (t1 - t0) / len(new_t)
                for k, t in enumerate(new_t):
                    if k == len(new_t) - 1 and tail and not re.search(r"[.,!?…:;]$", t):
                        t += tail.group()
                    out.append({"text": t, "start": t0 + k * step, "end": t0 + (k + 1) * step})
                i += n
            else:
                out.append(words[i])
                i += 1
        words = out
    return words


def transcribe(path, model_size, lang):
    """Transcreve com faster-whisper. Retorna None se o Whisper não estiver instalado."""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        return None
    os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
    os.environ.setdefault("HF_HUB_VERBOSITY", "error")
    log(f"Transcrevendo a fala ({model_size})…")
    try:
        model = WhisperModel(model_size, device="cpu", compute_type="int8", local_files_only=True)
    except Exception:  # noqa: BLE001
        log("Baixando o modelo de transcrição (só na primeira vez)…")
        model = WhisperModel(model_size, device="cpu", compute_type="int8")
    segments, _ = model.transcribe(str(path), language=lang, word_timestamps=True, vad_filter=True)
    return [{"text": w.word.strip(), "start": w.start, "end": w.end}
            for seg in segments for w in (seg.words or []) if w.word.strip()]


def keep_from_words(words, max_gap, pad, duration):
    """Trechos mantidos a partir das palavras: pausas maiores que max_gap viram corte."""
    segs = []
    for w in words:
        if segs and w["start"] - segs[-1][1] <= max_gap:
            segs[-1][1] = w["end"]
        else:
            segs.append([w["start"], w["end"]])
    return pad_and_merge(segs, pad, duration)
