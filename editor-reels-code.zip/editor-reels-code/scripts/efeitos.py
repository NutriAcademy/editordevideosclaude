"""Receitas de efeitos: transições, cor, textura e áudio (filtros do FFmpeg)."""
import subprocess

from base import FFMPEG, ff_path, log

# Nome em português → transição do filtro xfade. "corte" e "glitch" são tratados à parte.
TRANSICOES = {
    "corte": None,
    "dissolver": "dissolve",
    "suave": "fade",
    "fade-preto": "fadeblack",
    "fade-branco": "fadewhite",
    "wipe-esquerda": "wipeleft",
    "wipe-direita": "wiperight",
    "wipe-cima": "wipeup",
    "deslizar-esquerda": "slideleft",
    "deslizar-direita": "slideright",
    "zoom": "zoomin",
    "circulo": "circleopen",
    "desfoque": "hblur",
    "pixelado": "pixelize",
    "glitch": None,
}

# Estilos de cor prontos (color grading).
ESTILOS = {
    "natural": "eq=contrast=1.05:saturation=1.08",
    "vivo": "eq=contrast=1.10:saturation=1.35:brightness=0.02",
    "quente": "colorchannelmixer=rr=1.06:gg=1.0:bb=0.90,eq=saturation=1.08",
    "frio": "colorchannelmixer=rr=0.94:gg=1.0:bb=1.08,eq=saturation=0.95",
    # Teal & orange: sombras azuladas, tons de pele mais quentes.
    "cinema": "curves=r='0/0 0.5/0.53 1/1':b='0/0.06 0.5/0.47 1/0.94',eq=contrast=1.12:saturation=0.95",
    "nostalgia": "curves=preset=vintage,eq=saturation=0.85,noise=alls=8:allf=t",
    "suspense": "curves=r='0/0 0.5/0.45 1/0.95':b='0/0.08 0.5/0.55 1/1',eq=contrast=1.15:brightness=-0.04:saturation=0.70",
    "pb": "hue=s=0,eq=contrast=1.10",
    "drama": "hue=s=0,eq=contrast=1.35:brightness=-0.03,vignette=PI/4",
    "sepia": "colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:.272:.534:.131",
}


def auto_color(paths):
    """Mede a cor média de alguns quadros e devolve um ajuste de balanço de branco e exposição.

    Bem mais rápido que um filtro automático quadro a quadro: a medição é feita uma vez,
    em quadros pequenos, e o ajuste aplicado é um simples ganho por canal.
    """
    import numpy as np
    pixels = []
    for path in paths:
        raw = subprocess.run([FFMPEG, "-v", "error", "-i", str(path), "-vf", "fps=1,scale=64:114",
                              "-frames:v", "12", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                             capture_output=True).stdout
        if raw:
            pixels.append(np.frombuffer(raw, np.uint8).reshape(-1, 3).astype(np.float64))
    if not pixels:
        return []
    px = np.concatenate(pixels)
    luma = px @ [0.299, 0.587, 0.114]
    mid = px[(luma > 30) & (luma < 230)]          # ignora pretos e brancos estourados
    mean = mid.mean(axis=0) if len(mid) else px.mean(axis=0)
    gray = mean.mean()
    # Corrige só metade do desvio: mantém o clima da cena e evita exageros.
    gains = [1 + 0.5 * (gray / m - 1) for m in mean]
    gains = [min(1.25, max(0.8, g)) for g in gains]
    target, cur = 118.0, float(np.median(luma))
    gamma = min(1.35, max(0.8, (np.log(max(cur, 1) / 255) / np.log(target / 255)) ** 0.5))
    log(f"Correção de cor: R×{gains[0]:.2f} G×{gains[1]:.2f} B×{gains[2]:.2f}, gama {gamma:.2f}")
    return [f"colorchannelmixer=rr={gains[0]:.3f}:gg={gains[1]:.3f}:bb={gains[2]:.3f}",
            f"eq=gamma={gamma:.3f}:contrast=1.04:saturation=1.06"]


def color_chain(args, paths=()):
    """Correção de cor, estilo, LUT e ajustes finos, na ordem certa."""
    chain = []
    if args.corrigir_cor:
        chain += auto_color(paths)
    if args.estilo:
        chain.append(ESTILOS[args.estilo])
    if args.lut:
        chain.append(f"lut3d=file='{ff_path(args.lut)}'")
    fine = []
    if args.brilho is not None:
        fine.append(f"brightness={args.brilho}")
    if args.contraste is not None:
        fine.append(f"contrast={args.contraste}")
    if args.saturacao is not None:
        fine.append(f"saturation={args.saturacao}")
    if fine:
        chain.append("eq=" + ":".join(fine))
    return chain


def texture_chain(args):
    chain = []
    if args.granulado:
        chain.append(f"noise=alls={int(args.granulado)}:allf=t+u")
    if args.vinheta:
        chain.append("vignette=PI/5")
    return chain


def voice_chain(args):
    """Tratamento da voz: limpeza, equalização e volume."""
    chain = []
    if args.reduzir_ruido:
        chain += ["highpass=f=80", "afftdn=nr=14:nf=-35:tn=1"]
    if args.voz == "clara":
        chain += ["highpass=f=90", "equalizer=f=250:t=q:w=1:g=-2", "equalizer=f=3500:t=q:w=1.2:g=3"]
    elif args.voz == "encorpada":
        chain += ["equalizer=f=140:t=q:w=1:g=3", "equalizer=f=6000:t=q:w=1:g=-1.5"]
    if args.normalizar:
        chain += ["loudnorm=I=-14:TP=-1.5:LRA=11", "aresample=48000"]
    return chain


def parse_range(text, default_end):
    """'5-8' → (5.0, 8.0); 'tudo' → (0, fim)."""
    if not text or text == "tudo":
        return 0.0, default_end
    a, b = text.split("-", 1)
    return float(a), float(b)


def stabilize_detect(path, out_trf):
    """1ª etapa da estabilização: mede o tremor do vídeo (gera um arquivo de movimentos)."""
    log(f"Medindo o tremor de {path.name}…")
    subprocess.run([FFMPEG, "-y", "-v", "error", "-i", str(path), "-an", "-vf",
                    f"vidstabdetect=shakiness=5:accuracy=5:stepsize=12:result='{ff_path(out_trf)}'",
                    "-f", "null", "-"], check=True)


def stabilize_filter(trf):
    # Interpolação linear: a bicúbica padrão é muitas vezes mais lenta nesse tamanho de vídeo.
    return f"vidstabtransform=input='{ff_path(trf)}':smoothing=15:interpol=linear:zoom=3"
