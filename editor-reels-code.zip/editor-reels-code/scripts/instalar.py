#!/usr/bin/env python3
"""Instala o Editor de Reels neste computador (Mac, Windows ou Linux).

Cria um ambiente Python isolado em ~/.editor-reels, instala o Whisper (transcrição)
e um FFmpeg próprio, baixa o modelo de transcrição e confere se tudo funciona.
Pode ser rodado de novo sem problema: só instala o que falta.
"""
import os
import platform
import subprocess
import sys
import venv
from pathlib import Path

HOME = Path.home() / ".editor-reels"
VENV = HOME / "venv"
PY = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
PACKAGES = ["faster-whisper", "imageio-ffmpeg", "numpy"]


def step(msg):
    print(f"▸ {msg}", flush=True)


def main():
    model = sys.argv[1] if len(sys.argv) > 1 else "small"
    if sys.version_info < (3, 9):
        sys.exit(f"É preciso Python 3.9 ou mais novo (este é {platform.python_version()}).")
    HOME.mkdir(parents=True, exist_ok=True)

    if not PY.exists():
        step("Criando o ambiente do editor…")
        venv.EnvBuilder(with_pip=True).create(VENV)

    step("Instalando o Whisper e o FFmpeg (pode levar alguns minutos)…")
    subprocess.run([str(PY), "-m", "pip", "install", "-q", "--upgrade", "pip"], check=True)
    subprocess.run([str(PY), "-m", "pip", "install", "-q", "--upgrade", *PACKAGES], check=True)

    step(f"Baixando o modelo de transcrição '{model}' (só na primeira vez)…")
    env = dict(os.environ, HF_HUB_DISABLE_XET="1", HF_HUB_VERBOSITY="error", HF_HUB_DISABLE_TELEMETRY="1")
    check = (
        "import imageio_ffmpeg, subprocess;"
        "from faster_whisper import WhisperModel;"
        f"WhisperModel('{model}', device='cpu', compute_type='int8');"
        "ff = imageio_ffmpeg.get_ffmpeg_exe();"
        "out = subprocess.run([ff, '-hide_banner', '-filters'], capture_output=True, text=True).stdout;"
        "assert ' ass ' in out, 'FFmpeg sem suporte a legenda';"
        "print(ff)"
    )
    r = subprocess.run([str(PY), "-c", check], env=env, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit(f"A verificação falhou:\n{r.stderr[-1500:]}")

    (HOME / "correcoes.txt").touch(exist_ok=True)
    step("Tudo pronto!")
    print(f"PYTHON_DO_EDITOR={PY}")


if __name__ == "__main__":
    main()
